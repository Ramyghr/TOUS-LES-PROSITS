package tn.esprit.gestionzoo.entites;

public enum Food {
    MEAT,
    PLANT,
    BOTH
}