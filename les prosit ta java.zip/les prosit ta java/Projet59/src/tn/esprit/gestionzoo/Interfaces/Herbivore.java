package tn.esprit.gestionzoo.Interfaces;

public interface Herbivore<T>{
    public void eatPlant(T plant);
}
