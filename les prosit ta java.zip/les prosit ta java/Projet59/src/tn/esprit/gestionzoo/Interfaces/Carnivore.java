package tn.esprit.gestionzoo.Interfaces;

public interface Carnivore<T> {
    public void eatMeat(T meat);

}
